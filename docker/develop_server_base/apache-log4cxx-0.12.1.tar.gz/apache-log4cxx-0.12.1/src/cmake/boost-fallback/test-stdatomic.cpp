#include <atomic>

int main(int argc, char** argv){
	std::atomic<bool> b;
}
