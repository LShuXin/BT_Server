#include <boost/thread.hpp>

int main(int argc, char** argv){
	boost::mutex mutex;
	return 0;
}
